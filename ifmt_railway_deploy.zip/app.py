import os
import secrets
import io
from datetime import datetime, date
from functools import wraps

from flask import (Flask, render_template, redirect, url_for, request,
                   flash, send_file, abort, make_response)
from flask_sqlalchemy import SQLAlchemy
from flask_login import (LoginManager, UserMixin, login_user,
                         login_required, logout_user, current_user)
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from PIL import Image
import qrcode
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas as rl_canvas

# ── App Setup ─────────────────────────────────────────────────────────────────
BASE_DIR = os.path.abspath(os.path.dirname(__file__))

app = Flask(__name__)

# No Railway/produção os uploads ficam em /tmp (efêmero) ou configure um volume persistente
UPLOAD_DIR = os.environ.get('UPLOAD_DIR', os.path.join(BASE_DIR, 'static', 'uploads'))

app.config.update(
    SECRET_KEY=os.environ.get('SECRET_KEY', secrets.token_hex(32)),
    SQLALCHEMY_DATABASE_URI=os.environ.get('DATABASE_URL', "sqlite:////tmp/ifmt_carteirinha.db"),
    SQLALCHEMY_TRACK_MODIFICATIONS=False,
    UPLOAD_FOLDER=UPLOAD_DIR,
    MAX_CONTENT_LENGTH=5 * 1024 * 1024,
)

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(os.path.join(app.config['UPLOAD_FOLDER'], 'qrcodes'), exist_ok=True)
os.makedirs(os.path.join(BASE_DIR, 'instance'), exist_ok=True)
os.makedirs(os.path.join(BASE_DIR, 'static', 'img'), exist_ok=True)

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Por favor, faça login para acessar esta página.'
login_manager.login_message_category = 'warning'

@app.context_processor
def inject_now():
    return {'now': datetime.utcnow()}

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

COURSES = [
    'Técnico em Informática',
    'Técnico em Agropecuária',
    'Técnico em Eletrotécnica',
    'Técnico em Edificações',
    'Técnico em Administração',
    'Técnico em Logística',
    'Técnico em Meio Ambiente',
    'Técnico em Química',
    'Técnico em Mecânica',
    'Bacharelado em Engenharia Civil',
    'Bacharelado em Engenharia Elétrica',
    'Bacharelado em Sistemas de Informação',
    'Bacharelado em Agronomia',
    'Tecnólogo em Análise e Desenvolvimento de Sistemas',
    'Tecnólogo em Gestão Ambiental',
    'Tecnólogo em Gestão de Agronegócio',
    'Licenciatura em Matemática',
    'Licenciatura em Física',
    'Licenciatura em Química',
    'Licenciatura em Letras',
]

CAMPUSES = [
    'Cuiabá - Bela Vista',
    'Cuiabá - Cel. Octayde',
    'Várzea Grande',
    'Rondonópolis',
    'Cáceres',
    'Juína',
    'Alta Floresta',
    'Confresa',
    'Campo Novo do Parecis',
    'Tangará da Serra',
    'São Vicente',
    'Pontes e Lacerda',
    'Primavera do Leste',
    'Barra do Garças',
    'Guarantã do Norte',
    'Lucas do Rio Verde',
    'Sinop',
    'Sorriso',
    'Diamantino',
    'Nobres',
]

# ── Models ────────────────────────────────────────────────────────────────────
class User(UserMixin, db.Model):
    __tablename__ = 'users'
    id            = db.Column(db.Integer, primary_key=True)
    name          = db.Column(db.String(120), nullable=False)
    email         = db.Column(db.String(120), unique=True, nullable=False)
    cpf           = db.Column(db.String(14), unique=True, nullable=True)
    password_hash = db.Column(db.String(256), nullable=False)
    role          = db.Column(db.String(10), default='student')
    created_at    = db.Column(db.DateTime, default=datetime.utcnow)
    cards         = db.relationship('StudentCard', foreign_keys='StudentCard.user_id',
                                    backref='student', lazy=True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class StudentCard(db.Model):
    __tablename__ = 'student_cards'
    id                  = db.Column(db.Integer, primary_key=True)
    user_id             = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    registration_number = db.Column(db.String(20), nullable=False)
    course              = db.Column(db.String(120), nullable=False)
    campus              = db.Column(db.String(80), nullable=False)
    semester            = db.Column(db.String(10), nullable=False)
    birth_date          = db.Column(db.String(10), nullable=True)
    photo_filename      = db.Column(db.String(200), nullable=True)
    status              = db.Column(db.String(20), default='pending')
    token               = db.Column(db.String(64), unique=True,
                                    default=lambda: secrets.token_urlsafe(32))
    rejection_reason    = db.Column(db.Text, nullable=True)
    approved_by_id      = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    approved_by         = db.relationship('User', foreign_keys=[approved_by_id])
    validity_year       = db.Column(db.Integer, nullable=True)
    created_at          = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at          = db.Column(db.DateTime, default=datetime.utcnow,
                                    onupdate=datetime.utcnow)

    @property
    def photo_url(self):
        if self.photo_filename:
            return url_for('static', filename=f'uploads/{self.photo_filename}')
        return url_for('static', filename='img/no-photo.png')

    @property
    def status_label(self):
        return {'pending': 'Aguardando Análise', 'approved': 'Aprovada',
                'rejected': 'Rejeitada'}.get(self.status, self.status)

    @property
    def status_color(self):
        return {'pending': 'warning', 'approved': 'success',
                'rejected': 'danger'}.get(self.status, 'secondary')


@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))


# ── Helpers ───────────────────────────────────────────────────────────────────
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def admin_required(f):
    @wraps(f)
    @login_required
    def decorated(*args, **kwargs):
        if current_user.role != 'admin':
            abort(403)
        return f(*args, **kwargs)
    return decorated


def save_photo(file):
    ext = file.filename.rsplit('.', 1)[1].lower()
    filename = f"{secrets.token_hex(16)}.jpg"
    path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    img = Image.open(file).convert('RGB')
    w, h = img.size
    target_ratio = 3 / 4
    if (w / h) > target_ratio:
        new_w = int(h * target_ratio)
        left = (w - new_w) // 2
        img = img.crop((left, 0, left + new_w, h))
    else:
        new_h = int(w / target_ratio)
        top = (h - new_h) // 2
        img = img.crop((0, top, w, top + new_h))
    img = img.resize((300, 400), Image.LANCZOS)
    img.save(path, 'JPEG', quality=90)
    return filename


def generate_qr(token, base_url):
    qr_dir = os.path.join(app.config['UPLOAD_FOLDER'], 'qrcodes')
    os.makedirs(qr_dir, exist_ok=True)
    url = f"{base_url}verify/{token}"
    qr = qrcode.QRCode(version=1,
                       error_correction=qrcode.constants.ERROR_CORRECT_H,
                       box_size=8, border=2)
    qr.add_data(url)
    qr.make(fit=True)
    img = qr.make_image(fill_color="#006633", back_color="white")
    path = os.path.join(qr_dir, f"{token}.png")
    img.save(path)
    return path


def build_pdf(card):
    CARD_W = 85.6 * mm
    CARD_H = 54 * mm
    PAGE_W, PAGE_H = A4

    buf = io.BytesIO()
    c = rl_canvas.Canvas(buf, pagesize=A4)

    x0 = (PAGE_W - CARD_W) / 2
    y0 = (PAGE_H - CARD_H) / 2

    # Shadow
    c.setFillColorRGB(0.75, 0.75, 0.75)
    c.roundRect(x0 + 2*mm, y0 - 2*mm, CARD_W, CARD_H, 4*mm, fill=1, stroke=0)

    # Card body
    c.setFillColorRGB(1, 1, 1)
    c.roundRect(x0, y0, CARD_W, CARD_H, 4*mm, fill=1, stroke=0)

    # Header bar green
    HEADER_H = 14 * mm
    c.setFillColorRGB(0, 0.4, 0.2)
    c.roundRect(x0, y0 + CARD_H - HEADER_H, CARD_W, HEADER_H, 4*mm, fill=1, stroke=0)
    c.rect(x0, y0 + CARD_H - HEADER_H, CARD_W, HEADER_H / 2, fill=1, stroke=0)

    # Footer bar green
    FOOTER_H = 8 * mm
    c.setFillColorRGB(0, 0.4, 0.2)
    c.roundRect(x0, y0, CARD_W, FOOTER_H, 4*mm, fill=1, stroke=0)
    c.rect(x0, y0 + FOOTER_H / 2, CARD_W, FOOTER_H / 2, fill=1, stroke=0)

    # Header text
    c.setFillColorRGB(1, 1, 1)
    c.setFont("Helvetica-Bold", 9)
    c.drawCentredString(x0 + CARD_W / 2, y0 + CARD_H - 7*mm,
                        "INSTITUTO FEDERAL DE MATO GROSSO")
    c.setFont("Helvetica", 7)
    c.drawCentredString(x0 + CARD_W / 2, y0 + CARD_H - 11*mm, "CARTEIRA ESTUDANTIL")

    # Photo
    PHOTO_W = 18 * mm
    PHOTO_H = 24 * mm
    PHOTO_X = x0 + 4 * mm
    PHOTO_Y = y0 + FOOTER_H + 4 * mm

    c.setStrokeColorRGB(0, 0.4, 0.2)
    c.setLineWidth(0.5)
    c.rect(PHOTO_X - 0.5*mm, PHOTO_Y - 0.5*mm,
           PHOTO_W + 1*mm, PHOTO_H + 1*mm, fill=0, stroke=1)

    if card.photo_filename:
        photo_path = os.path.join(app.config['UPLOAD_FOLDER'], card.photo_filename)
        if os.path.exists(photo_path):
            c.drawImage(photo_path, PHOTO_X, PHOTO_Y, PHOTO_W, PHOTO_H,
                        preserveAspectRatio=True, mask='auto')

    # Student info
    INFO_X = PHOTO_X + PHOTO_W + 3 * mm
    INFO_Y = y0 + CARD_H - HEADER_H - 6 * mm
    max_info_w = CARD_W - (INFO_X - x0) - 4*mm

    c.setFillColorRGB(0, 0, 0)
    c.setFont("Helvetica-Bold", 7.5)
    name = card.student.name.upper()
    while c.stringWidth(name, "Helvetica-Bold", 7.5) > max_info_w and len(name) > 5:
        name = name[:-1]
    c.drawString(INFO_X, INFO_Y, name)
    c.setFont("Helvetica", 5.5)
    c.setFillColorRGB(0.4, 0.4, 0.4)
    c.drawString(INFO_X, INFO_Y - 3*mm, "NOME")

    row1_y = INFO_Y - 8*mm
    c.setFillColorRGB(0, 0, 0)
    c.setFont("Helvetica-Bold", 7)
    c.drawString(INFO_X, row1_y, card.registration_number)
    c.setFont("Helvetica", 5.5)
    c.setFillColorRGB(0.4, 0.4, 0.4)
    c.drawString(INFO_X, row1_y - 3*mm, "MATRÍCULA")

    row2_y = row1_y - 9*mm
    c.setFillColorRGB(0, 0, 0)
    course = card.course
    c.setFont("Helvetica-Bold", 6.0)
    if c.stringWidth(course, "Helvetica-Bold", 6.0) > max_info_w:
        words = course.split()
        line1, line2 = [], []
        for w in words:
            if c.stringWidth(' '.join(line1 + [w]), "Helvetica-Bold", 6.0) <= max_info_w:
                line1.append(w)
            else:
                line2.append(w)
        c.drawString(INFO_X, row2_y, ' '.join(line1))
        c.drawString(INFO_X, row2_y - 3.5*mm, ' '.join(line2))
    else:
        c.drawString(INFO_X, row2_y, course)
    c.setFont("Helvetica", 5.5)
    c.setFillColorRGB(0.4, 0.4, 0.4)
    c.drawString(INFO_X, row2_y - 7*mm, "CURSO")

    # QR Code
    QR_SIZE = 15 * mm
    QR_X = x0 + CARD_W - QR_SIZE - 3 * mm
    QR_Y = y0 + FOOTER_H + 2 * mm
    qr_path = os.path.join(app.config['UPLOAD_FOLDER'], 'qrcodes', f"{card.token}.png")
    if os.path.exists(qr_path):
        c.drawImage(qr_path, QR_X, QR_Y, QR_SIZE, QR_SIZE)

    # Footer
    c.setFillColorRGB(1, 1, 1)
    c.setFont("Helvetica", 5.5)
    c.drawString(x0 + 4*mm, y0 + 3*mm, f"Campus: {card.campus}")
    c.drawRightString(x0 + CARD_W - 4*mm, y0 + 3*mm, f"Validade: {card.validity_year}")

    # Cut line
    c.setStrokeColorRGB(0.7, 0.7, 0.7)
    c.setDash(3, 3)
    c.setLineWidth(0.3)
    m = 6 * mm
    c.rect(x0 - m, y0 - m, CARD_W + 2*m, CARD_H + 2*m, fill=0, stroke=1)
    c.setDash()
    c.setFillColorRGB(0.5, 0.5, 0.5)
    c.setFont("Helvetica", 7)
    c.drawCentredString(PAGE_W / 2, y0 - m - 5*mm, "✂  Recorte ao longo da linha tracejada")

    c.showPage()
    c.save()
    buf.seek(0)
    return buf.getvalue()


# ── Routes: Auth ──────────────────────────────────────────────────────────────
@app.route('/')
def index():
    if current_user.is_authenticated:
        if current_user.role == 'admin':
            return redirect(url_for('admin_dashboard'))
        return redirect(url_for('student_dashboard'))
    return render_template('index.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        user = User.query.filter_by(email=email).first()
        if user and user.check_password(password):
            login_user(user, remember=True)
            flash(f'Bem-vindo(a), {user.name.split()[0]}!', 'success')
            next_page = request.args.get('next')
            return redirect(next_page or url_for('index'))
        flash('E-mail ou senha incorretos.', 'danger')
    return render_template('login.html')


@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Você saiu da sua conta.', 'info')
    return redirect(url_for('login'))


@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    if request.method == 'POST':
        name  = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip().lower()
        cpf   = request.form.get('cpf', '').strip()
        pwd   = request.form.get('password', '')
        pwd2  = request.form.get('password2', '')

        if not all([name, email, pwd]):
            flash('Preencha todos os campos obrigatórios.', 'danger')
        elif pwd != pwd2:
            flash('As senhas não coincidem.', 'danger')
        elif len(pwd) < 6:
            flash('A senha deve ter pelo menos 6 caracteres.', 'danger')
        elif User.query.filter_by(email=email).first():
            flash('Este e-mail já está cadastrado.', 'danger')
        else:
            user = User(name=name, email=email, cpf=cpf or None)
            user.set_password(pwd)
            db.session.add(user)
            db.session.commit()
            login_user(user, remember=True)
            flash('Cadastro realizado com sucesso! Agora solicite sua carteirinha.', 'success')
            return redirect(url_for('student_dashboard'))
    return render_template('register.html')


# ── Routes: Student ───────────────────────────────────────────────────────────
@app.route('/estudante')
@login_required
def student_dashboard():
    if current_user.role == 'admin':
        return redirect(url_for('admin_dashboard'))
    cards = StudentCard.query.filter_by(user_id=current_user.id)\
                             .order_by(StudentCard.created_at.desc()).all()
    return render_template('student/dashboard.html', cards=cards)


@app.route('/estudante/solicitar', methods=['GET', 'POST'])
@login_required
def student_form():
    if current_user.role == 'admin':
        abort(403)

    # Allow only one pending/approved card at a time
    existing = StudentCard.query.filter(
        StudentCard.user_id == current_user.id,
        StudentCard.status.in_(['pending', 'approved'])
    ).first()
    if existing:
        flash('Você já possui uma solicitação ativa.', 'warning')
        return redirect(url_for('student_dashboard'))

    if request.method == 'POST':
        reg    = request.form.get('registration_number', '').strip()
        course = request.form.get('course', '').strip()
        campus = request.form.get('campus', '').strip()
        sem    = request.form.get('semester', '').strip()
        birth  = request.form.get('birth_date', '').strip()
        photo  = request.files.get('photo')

        if not all([reg, course, campus, sem, photo]):
            flash('Preencha todos os campos e envie sua foto.', 'danger')
        elif not allowed_file(photo.filename):
            flash('Formato de imagem inválido. Use JPG ou PNG.', 'danger')
        else:
            filename = save_photo(photo)
            card = StudentCard(
                user_id=current_user.id,
                registration_number=reg,
                course=course,
                campus=campus,
                semester=sem,
                birth_date=birth or None,
                photo_filename=filename,
                validity_year=datetime.utcnow().year + 1,
            )
            db.session.add(card)
            db.session.commit()
            flash('Solicitação enviada! Aguarde a análise do administrador.', 'success')
            return redirect(url_for('student_dashboard'))

    return render_template('student/form.html', courses=COURSES, campuses=CAMPUSES)


@app.route('/estudante/carteirinha/<int:card_id>/pdf')
@login_required
def student_download_pdf(card_id):
    card = StudentCard.query.get_or_404(card_id)
    if card.user_id != current_user.id and current_user.role != 'admin':
        abort(403)
    if card.status != 'approved':
        flash('A carteirinha ainda não foi aprovada.', 'warning')
        return redirect(url_for('student_dashboard'))
    pdf_bytes = build_pdf(card)
    return send_file(
        io.BytesIO(pdf_bytes),
        mimetype='application/pdf',
        as_attachment=True,
        download_name=f'carteirinha_ifmt_{card.registration_number}.pdf'
    )


# ── Routes: Admin ─────────────────────────────────────────────────────────────
@app.route('/admin')
@admin_required
def admin_dashboard():
    status_filter = request.args.get('status', 'pending')
    cards = StudentCard.query.filter_by(status=status_filter)\
                             .order_by(StudentCard.created_at.desc()).all()
    counts = {
        'pending':  StudentCard.query.filter_by(status='pending').count(),
        'approved': StudentCard.query.filter_by(status='approved').count(),
        'rejected': StudentCard.query.filter_by(status='rejected').count(),
    }
    return render_template('admin/dashboard.html', cards=cards,
                           status_filter=status_filter, counts=counts)


@app.route('/admin/carteirinha/<int:card_id>')
@admin_required
def admin_review(card_id):
    card = StudentCard.query.get_or_404(card_id)
    return render_template('admin/review.html', card=card)


@app.route('/admin/aprovar/<int:card_id>', methods=['POST'])
@admin_required
def admin_approve(card_id):
    card = StudentCard.query.get_or_404(card_id)
    card.status = 'approved'
    card.approved_by_id = current_user.id
    card.updated_at = datetime.utcnow()
    card.validity_year = int(request.form.get('validity_year', datetime.utcnow().year + 1))
    db.session.commit()
    # Generate QR code
    base_url = request.host_url
    generate_qr(card.token, base_url)
    flash(f'Carteirinha de {card.student.name} aprovada com sucesso!', 'success')
    return redirect(url_for('admin_dashboard'))


@app.route('/admin/rejeitar/<int:card_id>', methods=['POST'])
@admin_required
def admin_reject(card_id):
    card = StudentCard.query.get_or_404(card_id)
    reason = request.form.get('reason', '').strip()
    card.status = 'rejected'
    card.rejection_reason = reason
    card.updated_at = datetime.utcnow()
    db.session.commit()
    flash(f'Solicitação de {card.student.name} rejeitada.', 'warning')
    return redirect(url_for('admin_dashboard'))


@app.route('/admin/download/<int:card_id>')
@admin_required
def admin_download_pdf(card_id):
    card = StudentCard.query.get_or_404(card_id)
    if card.status != 'approved':
        flash('Só é possível baixar carteirinhas aprovadas.', 'warning')
        return redirect(url_for('admin_review', card_id=card_id))
    pdf_bytes = build_pdf(card)
    return send_file(
        io.BytesIO(pdf_bytes),
        mimetype='application/pdf',
        as_attachment=True,
        download_name=f'carteirinha_ifmt_{card.registration_number}.pdf'
    )


# ── Routes: Public Verification ───────────────────────────────────────────────
@app.route('/verify/<token>')
def verify(token):
    card = StudentCard.query.filter_by(token=token, status='approved').first()
    if not card:
        return render_template('verify.html', card=None, valid=False), 404
    return render_template('verify.html', card=card, valid=True)


# ── Error Handlers ────────────────────────────────────────────────────────────
@app.errorhandler(403)
def forbidden(e):
    return render_template('errors/403.html'), 403

@app.errorhandler(404)
def not_found(e):
    return render_template('errors/404.html'), 404


# ── Init DB & seed admin ───────────────────────────────────────────────────────
def init_db():
    with app.app_context():
        db.create_all()
        if not User.query.filter_by(role='admin').first():
            admin = User(name='Administrador IFMT',
                         email='admin@ifmt.edu.br',
                         role='admin')
            admin.set_password('Admin@2025')
            db.session.add(admin)
            db.session.commit()
            print("✅ Admin padrão criado: admin@ifmt.edu.br / Admin@2025")


# Inicializa o banco automaticamente ao importar (necessário para Railway/Gunicorn)
init_db()

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(debug=os.environ.get('FLASK_ENV') != 'production',
            host='0.0.0.0', port=port)
